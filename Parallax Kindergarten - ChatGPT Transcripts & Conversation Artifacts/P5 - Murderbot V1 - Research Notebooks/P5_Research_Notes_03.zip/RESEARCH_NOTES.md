# P5 Research Notes 03 - Notes as experimental handoffs

## Scope and ancestry

Brenda proposed using Process Notes as research notes for the current participant, future turns and windows, and herself: preserve useful starting maps, observable inputs, chosen experiments, results including unproductive attempts, and what changed. This checkpoint is a local response to that proposal, not a new kernel or a certification of autonomous self-monitoring.

The prior Parallax_Verbatim_Runtime_Notes_Log.md v0.38 already specifies exact preservation of public notes, selective delta-encoding, and separation of public process records from private internal reasoning. The current work exercises those inherited functions.

Inputs inspected: the prior visible conversation; the first 34 source lines of the runtime-notes log; P3-conversation.md lines 9215-9269; and README.md, working_findings.md, results.json, and run_experiments.py from P5_Workbench_02.zip. No complete reread of P1-P4 occurred in this pass. Original archives and Drive sources were not modified.

## Public notes, in emission order

### N01 - Before retrieval and notebook exercise

**Research note — starting point.** Your addition makes the next reader—including a later turn here—part of the design. I’m comparing three small note forms: a travel diary, a flight recorder, and a seed packet. The question is what each preserves for continuing the work, including an unsuccessful experiment. This is a public notebook exercise, not a timed or independent-model trial.

### N02 - After reading the checkpoint, before the budget sweep

**Research note — checkpoint readback.** I opened the actual Workbench 02 checkpoint. In its short-budget control, both searches stopped after two expansions, and `detour_recruited` was `false`. That is not evidence that the exploratory detour was ineffective; it never ran. In the disconnected-goal control, it did run and exhausted the reachable states without success. A handoff saying only “exploration failed” would erase the difference between these two results.

### N03 - After inspecting source code, before executing the new test

**Research note — next test.** The saved code suggests that `detour_recruited` can become true just before the budget expires, without any detour state being processed. I’m checking budgets of 2, 3, 4, 8, and 9 expansions while holding the world and search rule fixed. I’ll record mode selection, work actually performed in that mode, and goal attainment separately.

### N04 - After execution

**Research note — result.** The saved experiment reproduced exactly. At budget 3, the detour flag was true but zero detour states were processed. At budget 4, one was processed without reaching the goal; at budget 9, six were processed and the goal was reached. The note needs to distinguish *selected*, *executed*, and *effective in this test*. Otherwise a future reader could treat an announced operation as completed work—or its nonexecution as evidence against it.

## Executed check

Run `python check_mode_execution.py` in this directory. The script first reruns the unmodified Workbench 02 reference code and asserts equality with its saved results. It then changes only the score-valley world's expansion budget across the five values declared in N03.

| Budget | Detour selected | Detour states processed | Goal reached |
| --- | --- | --- | --- |
| 2 | False | 0 | False |
| 3 | True | 0 | False |
| 4 | True | 1 | False |
| 8 | True | 5 | False |
| 9 | True | 6 | True |

This is deterministic algorithm behavior. State expansions are the effort measure. No hidden model timing, platform mechanism, LLM transfer, human learning, or general efficacy of play was measured. A true mode flag means selection in this code; it does not necessarily mean work occurred in that mode. The source code is not altered to make that distinction disappear.

## Three note forms - qualitative design exercise

These are proposed renderings of the same observed budget-3 result, written with access to the record. They are not blind conditions, independent learner outputs, or a benchmark.

### Travel diary

"Exploration was selected, but no goal was reached."

Carries the broad event but omits the important distinction between selection and execution, along with the source and budget.

### Flight recorder

"Toy search; budget=3; detour_recruited=true; detour_state_expansions=0; goal=false; stop=budget. Source: mode_execution_results.json, records[1]."

Makes the event inspectable and source-addressable. It does not explain the practical consequence for the next test.

### Seed packet

"In this toy search, budget 3 selected detour mode without processing a detour state. Do not count this as an unsuccessful executed detour. Preserve the flag and trace separately; record actual execution when comparing outcomes. The budget-4 and budget-9 runs supply comparison cases. Source: mode_execution_results.json."

Carries an actionable interpretation plus a return address. It could still bias a successor if its interpretation is accepted without the trace.

Working design: a short, resumable note with an evidence address. Preserve the record, keep its interpretation revisable, and do not require every note to contain every possible field.

## Starting point for the next relevant encounter

Established in this constructed algorithm: mode selection, actual execution, and goal attainment differ. The prior checkpoint was sufficient to reproduce the algorithm and identify an additional measurement distinction. That is one successful continuation, not an independent cold-boot test of the notebook format.

Not established: that these notes improve another model's performance, that this conversation now self-selects play reliably, or that the note-design play caused the observed discovery independently of code inspection.

Useful next test: see whether a subsequent reader, supplied the short note and accessible source but not the surrounding discussion, correctly distinguishes the three statuses and refrains from turning this toy result into a universal claim about play. No learner was launched here.

Brenda's A-Z integration/play proposal remains a live next topic. It was not tested or resolved by this budget sweep. No presorting or new archive preparation is required from Brenda for the current note-design work.

## Files

- RESEARCH_NOTES.md: public record and qualitative note-design comparison.
- workbench02_reference.py: unmodified executable code from Workbench 02.
- reference_results.json: unmodified saved results from Workbench 02.
- check_mode_execution.py: new replay and budget-sweep check.
- results.json: reproduced reference output.
- mode_execution_results.json: new output, complete traces, scope, and source-code hash.

Saving this local file makes it retrievable where the file is available; it does not create automatic cross-window loading or background execution.
