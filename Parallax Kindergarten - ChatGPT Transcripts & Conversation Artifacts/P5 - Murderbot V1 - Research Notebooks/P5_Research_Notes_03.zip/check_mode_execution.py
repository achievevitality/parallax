"""Check a public toy algorithm, not hidden LLM activity or human learning."""
from pathlib import Path
import contextlib
import hashlib
import io
import json
import runpy

ROOT = Path(__file__).resolve().parent
reference = ROOT / 'workbench02_reference.py'
with contextlib.redirect_stdout(io.StringIO()):
    ns = runpy.run_path(str(reference))
replayed = json.loads((ROOT / 'results.json').read_text())
original = json.loads((ROOT / 'reference_results.json').read_text())
assert replayed == original, 'Reference replay differs from the saved checkpoint.'

records = []
for budget in (2, 3, 4, 8, 9):
    result = ns['search'](ns['worlds'][0], True, budget=budget)
    executed = sum(item['mode'] == 'detour' for item in result['trace'])
    records.append({
        'budget_expansions': budget,
        'mode_selected': result['detour_recruited'],
        'detour_state_expansions': executed,
        'goal_reached': result['success'],
        'stop_reason': result['stop'],
        'trace': result['trace'],
    })

assert records[0]['mode_selected'] is False
assert records[1]['mode_selected'] is True and records[1]['detour_state_expansions'] == 0
assert records[2]['detour_state_expansions'] == 1 and not records[2]['goal_reached']
assert records[-1]['goal_reached'] is True
output = {
    'scope': 'Deterministic replay and budget sweep of a supplied toy search algorithm; not an LLM transfer or play-efficacy study.',
    'changed_variable': 'expansion budget only',
    'budgets_declared_before_run': [2, 3, 4, 8, 9],
    'effort_measure': 'state expansions; no model thinking-time measurement',
    'reference_replay_matches_saved_results': True,
    'source_code_sha256': hashlib.sha256(reference.read_bytes()).hexdigest(),
    'records': records,
}
(ROOT / 'mode_execution_results.json').write_text(json.dumps(output, indent=2) + '\n')
print('Reference replay matches saved results.')
for r in records:
    print('budget={budget_expansions}, selected={mode_selected}, executed={detour_state_expansions}, goal={goal_reached}, stop={stop_reason}'.format(**r))
