"""Follow-up prompted by the first integration result.

Test whether the successful B change should apply globally or only in
its relationship with the upgraded A. A-presence is explicitly known;
learning or sensing that presence is NOT supplied by this experiment.
"""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
import json
from coupled_regulators import gains, simulate


def run() -> dict:
    out = {}
    for policy in ('old_everywhere','new_everywhere','relationship_specific'):
        by_context = {}
        for a_present in (True,False):
            b = F(4,5) if policy == 'old_everywhere' else F(1,5)
            if policy == 'relationship_specific' and not a_present:
                b = F(4,5)
            ks=gains(F(6,5),b)
            if not a_present:
                del ks['A']
            trial=simulate(ks,F(1))
            trial['steps_to_error_below_0_001'] = next(
                (t['step'] for t in trial['trace'] if abs(t['after']) < 0.001), None)
            trial['B_gain']=float(b)
            by_context['A_present' if a_present else 'A_absent']=trial
        out[policy]=by_context
    assert out['old_everywhere']['A_present']['boundary_crossed']
    assert out['new_everywhere']['A_absent']['steps_to_error_below_0_001'] == 18
    assert out['relationship_specific']['A_absent']['steps_to_error_below_0_001'] == 3
    assert out['relationship_specific']['A_present']['steps_to_error_below_0_001'] == 11
    return {'scope':'Context test of a supplied conditional policy, not proof the nodes learned it.',
            'change_from_first_test':'A removed in an additional operating context; B policy scope varied.',
            'criterion':'first simulated step with absolute error below 0.001',
            'critical_assumption':'A presence is directly supplied; applicability detection is not learned or tested.',
            'results':out}

if __name__ == '__main__':
    results=run()
    Path(__file__).with_name('contextual_integration_results.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    for p,cs in results['results'].items():
        print(p,{c:{k:r[k] for k in ('B_gain','absolute_multiplier','boundary_crossed','steps_to_error_below_0_001')}
                 for c,r in cs.items()})
