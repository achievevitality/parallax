"""Finite constructed rehearsal after a capacity update.

A supplies work; B transfers it; C receives it. A increases from capacity
1 to 2. B and C already possess settings 1 and 2, but currently use 1.
Delivered work is min(A, B, C). Each setting above 1 has a stated cost.

Strict unilateral improvement can reject both intermediate adaptations,
while joint rehearsal can inspect their combination. The complete space
is only four configurations: this is exhaustive joint evaluation, not a
claim to reproduce human play or train an LLM.
"""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
from itertools import product
import hashlib
import json


STATES = tuple(product((1, 2), repeat=2))
BASE = (1, 1)


def evaluate(a: int, cost: F, state: tuple[int,int]) -> dict:
    b,c = state
    delivered = min(a,b,c)
    expense = cost * (b + c - 2)
    return {'state': list(state), 'delivered': delivered,
            'adaptation_cost': float(expense), 'net_value': float(F(delivered)-expense)}


def choose(records: list[dict]) -> dict:
    # Preserve the starting configuration when utility ties.
    return max(records, key=lambda r: (r['net_value'], -sum(r['state'])))


def unilateral(a: int, cost: F) -> dict:
    # Probe baseline plus the two one-node changes. Retain only strict gains.
    records = [evaluate(a,cost,s) for s in (BASE, (2,1), (1,2))]
    selected = choose(records)
    return {'method': 'strict unilateral improvement', 'trials': records,
            'selected': selected, 'tests_executed': len(records),
            'changed_from_baseline': selected['state'] != list(BASE)}


def joint(a: int, cost: F) -> dict:
    records = [evaluate(a,cost,s) for s in STATES]
    selected = choose(records)
    return {'method': 'bounded joint rehearsal / exhaustive enumeration',
            'mode_selected': True, 'trials': records,
            'tests_executed':len(records), 'selected':selected,
            'new_configuration_selected': selected['state'] != list(BASE),
            'net_improvement_found': selected['net_value'] > records[0]['net_value']}


def targeted(a: int, cost: F) -> dict:
    # Mechanism-informed comparison is a non-play control.
    # The mechanism is supplied, so baseline and jointly widened path suffice.
    records = [evaluate(a,cost,s) for s in (BASE,(2,2))]
    return {'method': 'mechanism-informed comparison (oracle model)',
            'tests_executed': len(records), 'trials':records, 'selected':choose(records)}


def run() -> dict:
    worlds = [('before_update',1,F(1,10)),
              ('after_update_low_cost',2,F(1,10)),
              ('after_update_high_cost',2,F(3,5)),
              ('after_update_tie',2,F(1,2))]
    results = {}
    for name,a,cost in worlds:
        results[name] = {'A_capacity':a,'cost_per_extra_setting':float(cost),
                         'old_task_check':evaluate(a,cost,BASE),
                         'unilateral':unilateral(a,cost),
                         'joint':joint(a,cost),
                         'mechanism_informed':targeted(a,cost)}
    low = results['after_update_low_cost']
    assert low['old_task_check']['delivered'] == results['before_update']['old_task_check']['delivered'] == 1
    assert low['unilateral']['selected']['state'] == [1,1]
    assert low['joint']['selected']['state'] == [2,2]
    assert low['joint']['selected']['net_value'] == 1.8
    assert low['mechanism_informed']['selected'] == low['joint']['selected']
    for name in ('before_update','after_update_high_cost','after_update_tie'):
        assert results[name]['joint']['selected']['state'] == [1,1]
        assert results[name]['joint']['tests_executed'] == 4
        assert not results[name]['joint']['net_improvement_found']
    return {'scope':'Specified three-stage capacity-and-cost model; not empirical developmental evidence.',
            'rules': ['delivered = min(A, B, C)', 'net = delivered - cost * ((B-1)+(C-1))',
                      'B and C can choose 1 or 2', 'prefer fewer changes on a tie'],
            'new_repertoire_definition': 'delivering 2 units rather than 1, with net value improvement where costs warrant it',
            'results':results,
            'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'limitations':['A, B, C are configured stages, not learning minds',
                           'Complete action space and mechanism were constructed by the experimenter',
                           'Net-value scale is stipulated, not a general account of human value',
                           'A knowledgeable non-play procedure obtains the same result',
                           'No noise, timing, confidence estimation or unknown dependencies are modeled']}


if __name__ == '__main__':
    out=run()
    Path(__file__).with_name('repertoire_results.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    for name,w in out['results'].items():
        print(name, 'old_task=',w['old_task_check']['delivered'],
              'unilateral=',w['unilateral']['selected'],
              'joint=',w['joint']['selected'],
              'joint_trials=',w['joint']['tests_executed'])
    print('After-update low-cost trials:',out['results']['after_update_low_cost']['joint']['trials'])
    print('All control assertions passed.')
