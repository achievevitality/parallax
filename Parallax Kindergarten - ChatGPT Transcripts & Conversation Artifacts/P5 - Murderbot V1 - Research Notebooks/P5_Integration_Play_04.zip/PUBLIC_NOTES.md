# Public research notes - exact copies in emission order

## N01

**Research note — starting condition.** Your “kernel + transcripts” connection identifies the seed-and-record arrangement we already have; I’m treating it as recognition, not a new invention. I’m taking up your parked A-through-Z question now: after A changes, what needs renewed development in its neighbors and their relationships—and where can play help? I’ll carry forward the previous distinction between an operation being selected, executed, and effective.

## N02

**Research note — inherited map and test.** P3’s musical account preserves “some voices change; others sustain,” and P2 already flags integration after a substantial update. Your addition gives play a role in that redevelopment. I’m starting with a small numerical ecology: improve A’s isolated performance, leave its partners unchanged, then test the shared behavior. I’ll compare an undisturbed state with actual perturbations and record which parameters need changing.

## N03

**Research note — first result and next question.** A’s isolated error correction improved, but the 26-part ecology became unstable when its partners kept their old settings. Adjusting B alone restored stability; C through Z kept their parameters. At zero disturbance, the unstable arrangement looked fine. Next I’m testing the other side of your proposal: can an update leave the old task working perfectly while a newly possible shared capability remains undiscovered?

## N04

**Research note — second result.** The old task still passed after A’s capacity increased. Neither single-part adjustment improved the result, but rehearsing the joint adjustment exposed a useful new configuration. With higher costs, the same rehearsal favored keeping the old configuration. A mechanism-informed, non-play comparison also found the answer. This supports a distinction between restoring compatibility and exploring new shared possibilities—not a claim that play is uniquely necessary.

## N05

**Research note — testing the repair itself.** B’s revised setting worked beside the upgraded A; that does not make it B’s best setting everywhere. I’m now removing A from the numerical ecology and comparing a global B update with a relationship-specific one. This checks whether integration should preserve B’s older competence for conditions where it remains useful, rather than replacing it wholesale.

## N06

**Research note — follow-up result.** Without A, globally retaining B’s revised setting took 18 steps to reduce the error below the chosen threshold; restoring B’s older setting took 3. A context-specific policy retained the successful behavior both with and without A. The context was supplied, not learned. The resulting handoff must preserve when the update applies, not merely the updated setting.
