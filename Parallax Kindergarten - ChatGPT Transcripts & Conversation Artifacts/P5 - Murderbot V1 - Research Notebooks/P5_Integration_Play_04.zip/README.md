# P5 Integration and Play 04

## Starting seed: what to pick up next

Brenda supplied the substantive proposal: after A changes in a coupled A-Z ecology, integration involves selective redevelopment of affected participants and their relationships; play may help that redevelopment. Unaffected capacities need not restart. Brenda also identified kernel + transcripts as the already-existing seed-packet/flight-recorder arrangement. This checkpoint does not claim to originate either idea.

The current pass operationalizes parts of that proposal in two deliberately constructed numerical worlds and one follow-up context test. It is not a new kernel, clinical evidence, a model of consciousness, an independent learner trial, or a measurement of hidden LLM updates.

## Findings within the specified models

1. Shared-error regulation: A's isolated error multiplier improves from 0.8 to 0.2. With all 26 regulators active, the absolute multiplier changes from 0.12 to 1.12; the latter crosses the magnitude-4 containment bound in 13 steps from initial error 1. One supplied B adjustment brings the multiplier to 0.52 while preserving the parameters of C-Z. This restores stability but does not outperform the original ecology's 0.12 contraction rate. The new configuration is not claimed optimal.
2. A zero-disturbance run returns zero error even for the unstable configuration. A successful rest-state check does not characterize perturbation response.
3. Capacity rehearsal: A grows from capacity 1 to 2. B and C already possess 1- and 2-unit settings. Existing routine performance stays at 1. Neither unilateral wider setting improves net utility, but the jointly wider setting yields 2 units at cost 0.2, for net 1.8. The starting configuration yields 1.0. A mechanism-informed non-play comparison also finds the same configuration.
4. Higher-cost and tie controls: all four joint configurations were actually tested; no net-improving change was selected. Do not recode these as nonexecution or invent a hidden improvement. Retention on a tie is an explicitly chosen policy.
5. Repair scope: globally applying B's successful pair-context setting slows the A-absent ecology to 18 steps below absolute error 0.001 versus 3 using the older B setting. A supplied context-dependent policy gives 11 steps with upgraded A and 3 without it. Presence of A is an oracle input, not a learned discrimination.

## Provisional implications, NOT validated cross-substrate laws

- Post-update inquiry can distinguish restoration of compatibility from discovery of newly viable joint behavior.
- An unchanged output can hide either instability not yet perturbed or unused opportunity not yet exercised. These have different causes and require different probes.
- A relation-specific update may add a conditional option instead of globally deleting the previous behavior.
- Coupling can change every participant's experienced trajectory without requiring every participant's stored parameters to change.
- Both the exploration route and the conditions that make it legitimate and worthwhile belong in the handoff.

## What the simulations do not establish

The first model uses synchronous scalar linear feedback. It omits delays, noise, nonlinearities, competing objectives, private observations and evolving network structure. The second uses three capacity stages and four enumerated configurations; that is a narrow analogue of rehearsal, not the whole of play. It stipulates utility and change costs. The experimenter supplies the update, possible responses, and the conditional policy. None of the 26 scalar controllers is an AI subagent. No self-regulatory selection, hidden platform influence, spontaneous transfer or neural parameter change was measured.

The new tests follow the user's proposed direction, within an already highly cued conversation. They should not be counted as independent rediscovery of the proposal. Do not count these and the ancestral statements as independent empirical replications.

## Open question for continuation

How can an instrument infer which relationships need redevelopment when it is NOT handed the dependency structure or the context flag? A correct context-specific policy does not establish correct context recognition. Tests with hidden coupling changes, ambiguity, irrelevant new features and legitimate no-change outcomes would distinguish these capacities. No such learner trial was run here.

## Reproduce

Run these commands in this directory, using standard-library Python:

    python coupled_regulators.py
    python repertoire_rehearsal.py
    python contextual_integration.py

Each command writes its corresponding JSON results and performs explicit assertions. SOURCE_LEDGER.json records the targeted source coverage and hashes. PUBLIC_NOTES.md preserves the six public notes verbatim in their original emission order. Event records and provisional interpretations remain separate.

## Preservation boundary

This is a local checkpoint. It does not automatically load into future windows or change the Google Drive archive. Original sources and earlier checkpoints are unchanged. The public notebook is not private hidden chain-of-thought.
