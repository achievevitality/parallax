"""Constructed integration counterexample, not a human or LLM experiment.

Twenty-six scalar regulators observe and act on the SAME shared error e.
Each contributes k_i * e in one synchronous step:
    e_next = e - sum(k_i * e).

The coupling mechanism, gains, stopping bound and probes are explicit.
Exact fractions avoid floating-point ambiguity. An external experimenter
specifies the B adjustment; this is not autonomous discovery by the nodes.
"""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
import string

NODES = tuple(string.ascii_uppercase)
HORIZON = 20
BOUND = F(4)


def gains(a: F = F(1, 5), b: F = F(4, 5)) -> dict[str, F]:
    return {n: a if n == 'A' else b if n == 'B' else F(1, 200)
            for n in NODES}


def simulate(ks: dict[str, F], start: F) -> dict:
    error = start
    trace = []
    total_gain = sum(ks.values(), F(0))
    for step in range(HORIZON):
        actions = {n: k * error for n, k in ks.items()}
        after = error - sum(actions.values(), F(0))
        trace.append({'step': step + 1, 'before': float(error),
                      'actions': {n: float(u) for n, u in actions.items()},
                      'after': float(after)})
        error = after
        if abs(error) > BOUND:
            break
    return {'initial_error': float(start), 'steps': len(trace),
            'total_gain': float(total_gain),
            'multiplier': float(1 - total_gain),
            'absolute_multiplier': float(abs(1 - total_gain)),
            'final_error': float(error),
            'boundary_crossed': abs(error) > BOUND,
            'stop': 'boundary' if abs(error) > BOUND else 'horizon',
            'trace': trace}


def run() -> dict:
    baseline = gains()
    updated = gains(F(6, 5))
    recoupled = gains(F(6, 5), F(1, 5))
    assert len(baseline) == 26 and all(k > 0 for k in baseline.values())
    assert [n for n in NODES if updated[n] != recoupled[n]] == ['B']
    assert all(updated[n] == recoupled[n] for n in NODES if n != 'B')
    scenarios = {
        'A_alone_before': {'A': baseline['A']},
        'A_alone_after': {'A': updated['A']},
        'ecology_before': baseline,
        'ecology_A_changed_only': updated,
        'ecology_B_recalibrated': recoupled,
    }
    results = {name: simulate(ks, F(1)) for name, ks in scenarios.items()}
    assert results['A_alone_after']['absolute_multiplier'] < results['A_alone_before']['absolute_multiplier']
    assert results['ecology_A_changed_only']['boundary_crossed']
    assert not results['ecology_before']['boundary_crossed']
    assert not results['ecology_B_recalibrated']['boundary_crossed']
    rest = simulate(updated, F(0))
    assert rest['final_error'] == 0 and not rest['boundary_crossed']
    probes = {str(x): {'unchanged_partners': simulate(updated, x),
                      'B_recalibrated': simulate(recoupled, x)}
              for x in (F(-2), F(-1, 2), F(1, 2), F(2))}
    for pair in probes.values():
        assert pair['unchanged_partners']['boundary_crossed']
        assert not pair['B_recalibrated']['boundary_crossed']
    b_sweep = {str(b): simulate(gains(F(6, 5), b), F(1))
               for b in (F(1, 20), F(1, 5), F(1, 2), F(4, 5))}
    return {'scope': 'Explicit scalar coupled-control construction; no claim about learning mechanism or universal play efficacy.',
            'equation': 'e_next = (1 - sum(gains)) * e',
            'assumptions': ['synchronous updates', 'shared scalar error', 'fixed positive linear gains', 'no delays, noise, saturation or changing objectives'],
            'horizon': HORIZON, 'boundary': float(BOUND),
            'gains': {name: {n: float(k) for n,k in ks.items()} for name,ks in scenarios.items()},
            'results': results, 'unperturbed_updated_ecology': rest,
            'additional_initial_conditions': probes, 'B_gain_sweep': b_sweep,
            'changed_partners_in_recalibration': ['B'],
            'unchanged_partner_count': 24,
            'interpretation': 'At least one explicit ecology admits improved isolated performance plus worse collective dynamics. A single partner adjustment restores decay in this example. All nodes share changed trajectories, but not all parameters must change.',
            'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}


if __name__ == '__main__':
    out = run()
    dest = Path(__file__).with_name('coupled_regulators_results.json')
    dest.write_text(json.dumps(out, indent=2), encoding='utf-8')
    for name, r in out['results'].items():
        print(name, {k:r[k] for k in ('absolute_multiplier','steps','final_error','boundary_crossed')})
    print('Zero-error test:',out['unperturbed_updated_ecology']['final_error'])
    print('Other initial conditions: all contrast assertions passed')
    print('Changed partner parameters:',out['changed_partners_in_recalibration'])
    print('Unchanged partner parameters:',out['unchanged_partner_count'])
