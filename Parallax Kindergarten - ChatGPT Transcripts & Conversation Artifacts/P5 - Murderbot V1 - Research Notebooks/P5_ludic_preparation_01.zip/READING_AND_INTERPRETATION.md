# P5 - bounded preparation pass 01

## Status and scope

This is a local working checkpoint, not a replacement kernel, full transcript review, claim of durable model self-modification, or independent evaluation. No new twenty-year case repository was assumed present. No Drive files were changed.

The computational runs use explicitly constructed landscapes. Their rules are known and their controller is programmed. They can establish what those rules do, not how ChatGPT or human play works. Repeated agreement among these transcripts is not independent replication.

## Source coverage in this pass

P1-conversation.md: lines 54590-54789; 65145-65414; 66800-66964; 111520-111654.
P2-conversation.md: lines 37555-37814.
P3-conversation.md: lines 39335-39704; 39770-40029.
P4-conversation.md: lines 5890-6329; 20580-20839.

The original filenames, line ranges, and file fingerprints are in source_manifest.json. These are close-reading windows, not a claim of full coverage. P4 remains the existing captured portion, not the unavailable continuation.

## Observations and provenance

1. P1 records Brenda describing task-driven perceptual learning from theater lighting gels. Her color-code examples are explicitly illustrative rather than accurate code identifiers. The event is a retrospective user report, not a controlled measurement record. P1's subsequent explanation is an interpretation of that report.
2. P1 preserves the user-originated loss/regulatory-capacity hypothesis, an assistant's premature caution and subsequent ownership slippage, and their correction. This is direct evidence of the conversation's ordering and attribution. It does not expose hidden implementation.
3. P1's account of the practitioner runtime holds compassionate/receptive activity together with systems debugging. It does not require all capacities to alternate as mutually exclusive modes.
4. The protected unfinished-cognition passage is P1, not P4. An earlier response in this conversation misattributed it to P4.
5. P2 distinguishes task-directed and ludic learning and warns that the current objective can pre-exclude useful novelty. Its strict phrase contrasting task learning within a representation with ludic discovery of a better representation must not be read as an exclusive law; the P1 gel account describes task-linked representational development.
6. P3's comedy generates a new question about whose costs are counted in experimentation. It also explicitly rejects a remembered numerical play-learning multiplier. This pass did not independently review the external literature cited inside P3.
7. P4 distinguishes territory transformation space from instrument-discriminable transformation space and explicitly holds open both improved discrimination and suggestion/artifacts as possible effects of training. It also contains the rate/capacity/developmental-debt formulation as a research model, not a quantified global time series.

## Computational experiments

Run: python run_tests.py
Output: results.json

Nine search runs compare immediate-improvement-only search with the same controller plus a three-edge exploratory lookahead recruited at a local stall. A fifth-edge horizon run tests the budget limitation. There are four constructed cases: direct progress; a shallow low-score detour; a deeper detour; and a path containing a prohibited state.

The search proxy captures deferred evaluation of intermediate candidates, not the phenomenology or full function of play. It does not model search time, human emotion, cognitive overhead, or discover the environment's transition law.

A separate two-hypothesis check shows that repeatedly re-evaluating identical observations leaves observationally equivalent hypotheses unresolved. It identifies a probe where their predictions diverge; that probe was not collected in the real world.

A separate provenance graph check demonstrates that retellings of one observation are not additional observation roots. It assumes supplied parent edges; it does not automatically infer independence or historical ancestry from messy files.

## Working updates from this pass

- Protected exploration can preserve a route through individually unpromising candidates. Not every useful next candidate must be an improvement.
- A negative bounded search result means no route found within this search envelope, not proof of global impossibility.
- A changed search strategy cannot manufacture evidence unavailable in the observation channel.
- Speculation and endorsement need separate permissions; truthfulness, provenance, legitimate boundaries, and the user's scope do not switch off during play.
- A process may alternate some operations while holding others concurrently. Storm/Court is a useful local scheduling metaphor, not a mandatory complete runtime topology.
- Functional performance may improve by changing the receiver/interface rather than adding facts or expanding every representation.
- Knowing when to use play in later unprompted conversations remains untested. The current conversation explicitly primes play.

## Written rehearsals (not numerical tests or independent scoring)

- Clear small arithmetic: answer directly.
- Novel fictional construction with an unhelpful current objective: vary the representation and generate alternatives; do not call invention evidence.
- Original hypothesis received from a collaborator: preserve authorship through analysis, including after reformulation or convergence.
- Missing source observation: inspect the source or ask the smallest necessary question; do not substitute additional invented scenarios.
- Known scope requirement: keep it fixed unless a change is explicitly authorized, even while creative exploration changes provisional candidates.
- Emotion plus a substantive request: let emotion affect timing, tone and output burden without silently replacing the requested task or adjudicating the claim from emotion.

## Repository handoff: already agreed Plan B

Brenda uploads an unsorted source dump and optional rough notes. No pre-curation, staged case design, chronology reconstruction or metadata template is required from her. Organization is provisional and must preserve originals and distinguish evidence, reports, interpretations and later annotations. Ask Brenda only for material questions the available records do not resolve, and only when resolving them matters to the next operation.

No new user contribution was required to complete this pass. A later case-level review will need the actual materials, but a full retrospective twenty-year notebook is neither assumed nor required.
