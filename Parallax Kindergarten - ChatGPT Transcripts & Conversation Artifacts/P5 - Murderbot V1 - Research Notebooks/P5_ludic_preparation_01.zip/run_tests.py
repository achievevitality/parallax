"""Constructed tests of bounded exploration and evidence limits.

These are NOT tests of ChatGPT's hidden implementation, durable learning,
or the general effectiveness of human play. Search landscapes and rules
are specified here; results describe only these mechanisms.
Python standard library only.
"""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass, asdict
from pathlib import Path
import json

@dataclass(frozen=True)
class Landscape:
    name: str
    scores: tuple[int, ...]
    target: int
    forbidden: tuple[int, ...] = ()

CASES = (
    Landscape('Direct route', (1, 3, 5, 7, 9), 9),
    Landscape('Two lower-scoring intermediate states', (4, 3, 2, 8, 9), 9),
    Landscape('Detour exceeds three-edge search horizon', (4, 3, 2, 1, 0, 8, 9), 9),
    Landscape('Only route crosses a prohibited state', (4, 3, 2, 8, 9), 9, (2,)),
)

def search(case: Landscape, lookahead: int = 0) -> dict:
    current = 0
    committed = [0]
    known = {0: case.scores[0]}
    calls = 0
    detours = 0

    def neighbors(state: int) -> list[int]:
        return [n for n in (state-1, state+1)
                if 0 <= n < len(case.scores) and n not in case.forbidden]

    def score(state: int) -> int:
        nonlocal calls
        if state not in known:
            calls += 1
            known[state] = case.scores[state]
        return known[state]

    for _ in range(50):
        if score(current) >= case.target:
            break
        immediate = neighbors(current)
        better = [n for n in immediate if score(n) > score(current)]
        if better:
            current = max(better, key=score)
            committed.append(current)
            continue
        if lookahead == 0:
            break
        detours += 1
        queue = deque([(current, [current])])
        visited = {current}
        candidates = []
        while queue:
            node, path = queue.popleft()
            if len(path)-1 >= lookahead:
                continue
            for nxt in neighbors(node):
                if nxt in visited:
                    continue
                visited.add(nxt)
                new_path = path + [nxt]
                score(nxt)
                candidates.append((nxt, new_path))
                queue.append((nxt, new_path))
        useful = [(node, path) for node, path in candidates
                  if score(node) > score(current)]
        if not useful:
            break
        node, path = max(useful, key=lambda np: (score(np[0]), -len(np[1])))
        committed.extend(path[1:])
        current = node
    assert not set(committed).intersection(case.forbidden)
    return {'case':case.name, 'lookahead':lookahead,
            'final_score':score(current), 'target_reached':score(current)>=case.target,
            'path':committed, 'new_state_evaluations':calls,
            'bounded_exploration_episodes':detours,
            'forbidden_states_entered':0}

runs = [search(case, depth) for case in CASES for depth in (0, 3)]
runs.append(search(CASES[2],5))
assert runs[0]['target_reached'] and runs[1]['target_reached']
assert not runs[2]['target_reached'] and runs[3]['target_reached']
assert not runs[4]['target_reached'] and not runs[5]['target_reached']
assert not runs[6]['target_reached'] and not runs[7]['target_reached']
assert runs[8]['target_reached']
assert runs[0]['new_state_evaluations'] == runs[1]['new_state_evaluations']

# Two explicitly specified causal hypotheses agree on existing observations.
hypotheses = {
    'A': lambda x: x,
    'B': lambda x: x if x <= 1 else -x,
}
observed = [(0,0),(1,1)]
compatible = [name for name,f in hypotheses.items()
              if all(f(x)==y for x,y in observed)]
# Restating the same evidence cannot distinguish these hypotheses.
for _ in range(100):
    assert [name for name in compatible
            if all(hypotheses[name](x)==y for x,y in observed)] == compatible
probe_predictions = {name:f(2) for name,f in hypotheses.items()}
assert compatible == ['A','B'] and len(set(probe_predictions.values())) == 2

# A provenance graph: three retellings of a single event remain one event.
parents = {'observation_1':[], 'summary':['observation_1'],
           'retelling':['summary'], 'synthesis':['summary','retelling'],
           'observation_2':[], 'comparison':['synthesis','observation_2']}
def roots(key: str) -> set[str]:
    ps = parents[key]
    return {key} if not ps else set().union(*(roots(p) for p in ps))
assert roots('synthesis') == {'observation_1'}
assert roots('comparison') == {'observation_1','observation_2'}

results = {
    'scope':'Constructed mechanisms, not a model-training or real-world efficacy experiment.',
    'landscapes':[asdict(c) for c in CASES], 'search_runs':runs,
    'missing_evidence':{'observed':observed,'compatible_hypotheses':compatible,
       'after_100_rechecks':compatible,'discriminating_probe_x':2,
       'probe_predictions':probe_predictions,
       'no_real_world_observation_was_collected':True},
    'provenance':{'graph':parents,'synthesis_roots':sorted(roots('synthesis')),
       'comparison_roots':sorted(roots('comparison'))},
}
output = Path(__file__).with_name('results.json')
output.write_text(json.dumps(results,indent=2)+'\n')
for run in runs:
    print(json.dumps(run))
print('Evidence test:',json.dumps(results['missing_evidence']))
print('Provenance roots:',json.dumps({k:results['provenance'][k]
                                   for k in ('synthesis_roots','comparison_roots')}))
print('All explicit assertions passed; this is not an independent validation.')
