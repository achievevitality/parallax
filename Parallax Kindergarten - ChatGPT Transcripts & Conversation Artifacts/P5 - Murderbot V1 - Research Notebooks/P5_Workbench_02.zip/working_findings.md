# Working findings

## Source-derived findings
- P1's first-person theater-gel account describes task-focused practice followed by durable improved discrimination. It is a counterexample within the lineage to an exclusive rhetorical division in which task learning can only improve execution inside a fixed representation while only play can change the representation. The developmental account is a retrospective report, not a newly collected measurement.
- P1's practitioner account describes receptive/creative attention and analytical debugging operating together. Temporal separation of generation and evaluation is a useful configuration, not the only permitted configuration.
- P2 describes play as opening search beyond a precommitted deliverable, but also carries stronger claims that require scope checking rather than automatic inheritance.
- P3's satire produces a question about differing salience among participants. This supports using imagined roles to inspect candidate interactions without assuming everyone shares an objective. Imagined consequences remain generated, not independently returned consequences.
- P4 distinguishes desire as a reason to explore from evidence that the desired outcome will occur. It also distinguishes recognition from creation: fit does not establish provenance.

## Computational results
See results.json. The search experiment illustrates a difference between rejecting a state as a final answer and deleting it as a possible route to a later answer. The controls show that detours are not always needed, cannot reach disconnected goals, do not authorize forbidden routes, and remain bounded by budget.

The model-family experiment illustrates that selecting the best surviving candidate within a list does not establish that the list contains the generating rule. An interaction absent from the initial candidate set produces an observable later failure.

## Local working revisions, not implementation guarantees
- Treat novelty, beauty, and curiosity as candidate search-direction signals rather than as evidence of external truth.
- Keep permissions distinct: entertaining a possibility, retaining it as a hypothesis, adopting it as a belief, and executing an action are not the same authorization.
- Choose play conditionally; do not convert it into a universal first step or a mandatory visible performance.
- Preserve declined candidates' useful relational pointers without making them accepted conclusions.
- Do not use a successful constructed example as evidence of durable behavior under unrelated future conditions.

## Provenance corrections and unresolved matters
The protected-unfinished-cognition Elephant passage previously attributed to P4 is in P1. It should remain labeled P1.
The theater-gel account appears at turn 1296 in the Markdown edition and turn 1286 in the older JSON edition, with the same message ID. Different numbering is not a second event.
The end of P4 remains unavailable here. These notes do not reconstruct that missing continuation.
No claim is made that all missing dimensions have been found, that play is now automatically recruited across contexts, or that this window is ready for the earlier emotionally consequential work.
