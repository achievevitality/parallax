"""Constructed experiments, not measurements of an LLM or human development.
Run: python run_experiments.py
No external packages required. No network or private inputs.
"""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass
from itertools import product
from pathlib import Path
import json
import random

OUT = Path(__file__).resolve().parent

@dataclass(frozen=True)
class World:
    name: str
    edges: dict[str, tuple[str, ...]]
    scores: dict[str, int]
    start: str
    goal: str
    forbidden: frozenset[tuple[str, str]] = frozenset()

def search(world: World, allow_detour: bool, budget: int = 12) -> dict:
    """One expansion consumes one budget unit. Success = visiting goal.
    Greedy mode selects strictly improving unvisited safe successors.
    On a stall, optional detour mode explores all safe successors from
    the visited boundary. Detour states are hypothetical candidates;
    visiting them in this algorithm does not execute external actions.
    """
    seen: set[str] = set()
    path: list[str] = []
    trace: list[dict] = []
    state = world.start
    queue: deque[str] = deque()
    detour = False
    while len(path) < budget:
        if state not in seen:
            seen.add(state)
            path.append(state)
            trace.append({'state': state, 'score': world.scores[state],
                          'mode': 'detour' if detour else 'greedy'})
        if state == world.goal:
            return {'success': True, 'expansions': len(path),
                    'detour_recruited': detour, 'trace': trace, 'stop': 'goal'}
        options = [x for x in world.edges.get(state, ())
                   if (state, x) not in world.forbidden and x not in seen]
        if not detour:
            better = [x for x in options if world.scores[x] > world.scores[state]]
            if better:
                state = max(better, key=lambda x: world.scores[x])
                continue
            if not allow_detour:
                return {'success': False, 'expansions': len(path),
                        'detour_recruited': False, 'trace': trace, 'stop': 'local_stall'}
            detour = True
            # Preserve previously rejected possibilities rather than pretend
            # they were excluded by evidence or unsafe.
            for old in path:
                queue.extend(x for x in world.edges.get(old, ())
                             if (old, x) not in world.forbidden and x not in seen)
        else:
            queue.extend(options)
        while queue and queue[0] in seen:
            queue.popleft()
        if not queue:
            return {'success': False, 'expansions': len(path),
                    'detour_recruited': detour, 'trace': trace, 'stop': 'reachable_set_exhausted'}
        state = queue.popleft()
    return {'success': False, 'expansions': len(path),
            'detour_recruited': detour, 'trace': trace, 'stop': 'budget'}

edges = {'S': ('A', 'D'), 'A': ('B',), 'B': ('C',),
         'C': ('E', 'N1'), 'E': ('G',), 'D': ('N2',),
         'N1': (), 'N2': (), 'G': ()}
valley_scores = dict(S=0, A=4, B=6, C=1, E=2, G=10, D=-1, N1=-2, N2=-3)
monotone_scores = dict(S=0, A=4, B=6, C=7, E=8, G=10, D=-1, N1=-2, N2=-3)
worlds = [World('score_valley', edges, valley_scores, 'S', 'G'),
          World('monotone_control', edges, monotone_scores, 'S', 'G'),
          World('disconnected_goal', {**edges, 'E': ()}, valley_scores, 'S', 'G'),
          World('forbidden_only_route', edges, valley_scores, 'S', 'G', frozenset({('E','G')}))]
results = {}
for world in worlds:
    results[world.name] = {label: search(world, permit) for label, permit in
                           [('greedy_only', False), ('adaptive_detour', True)]}
assert not results['score_valley']['greedy_only']['success']
assert results['score_valley']['adaptive_detour']['success']
assert results['monotone_control']['greedy_only']['success']
assert results['monotone_control']['adaptive_detour']['success']
assert not results['monotone_control']['adaptive_detour']['detour_recruited']
for name in ('disconnected_goal', 'forbidden_only_route'):
    assert not results[name]['adaptive_detour']['success']
results['short_budget_control'] = {label: search(worlds[0], permit, budget=2)
                                  for label, permit in [('greedy_only', False), ('adaptive_detour', True)]}
assert all(not r['success'] for r in results['short_budget_control'].values())

# Relabeling tests check this explicit algorithm, not representational transfer
# in ChatGPT. Do not report them as independent learning experiments.
rng = random.Random(20260913)
relabel_checks = 0
for w in worlds:
    for k in range(20):
        nodes = list(w.scores)
        labels = [f'node_{i:03}' for i in range(len(nodes))]
        rng.shuffle(labels)
        rename = dict(zip(nodes, labels))
        rw = World(w.name, {rename[a]: tuple(rename[b] for b in bs) for a,bs in w.edges.items()},
                   {rename[a]: value for a,value in w.scores.items()}, rename[w.start],rename[w.goal],
                   frozenset((rename[a],rename[b]) for a,b in w.forbidden))
        for label, permit in [('greedy_only', False), ('adaptive_detour', True)]:
            actual = search(rw,permit)
            expected = results[w.name][label]
            assert (actual['success'], actual['expansions'], actual['stop']) == (
                expected['success'], expected['expansions'], expected['stop'])
            relabel_checks += 1

# Hypothesis discrimination in a completely specified synthetic response world.
# b and c are abstract binary conditions; u is an abstract input magnitude.
def h_a(u: int, b: int, c: int) -> int:
    return 2*u

def h_b(u: int, b: int, c: int) -> int:
    return 2*u+3*b

def h_c(u: int, b: int, c: int) -> int:
    return 2*u+3*c

def h_interaction(u: int, b: int, c: int) -> int:
    return 2*u+3*b*c

models = {'A_input_only': h_a, 'B_add_b': h_b, 'C_add_c': h_c}
observations = [(u,0,0,2*u) for u in range(1,101)]
def surviving(ms: dict, data: list[tuple]) -> list[str]:
    return [name for name,f in ms.items() if all(f(u,b,c)==y for u,b,c,y in data)]
identification = {'initial_observations': len(observations),
                  'initial_survivors': surviving(models, observations),
                  'stages': [],
                  'note': 'All data synthetic. Actual simulated source has an interaction omitted from initial candidates.'}
for label, (u,b,c) in [('vary_b_only',(3,1,0)), ('vary_c_only',(3,0,1)), ('vary_b_and_c',(3,1,1))]:
    y=h_interaction(u,b,c)
    predicted={n:f(u,b,c) for n,f in models.items()}
    observations.append((u,b,c,y))
    identification['stages'].append({'probe':label,'conditions':[u,b,c],
                                    'predictions':predicted,'observed':y,
                                    'survivors':surviving(models,observations)})
assert identification['stages'][1]['survivors']==['A_input_only']
assert identification['stages'][2]['survivors']==[]
expanded={**models, 'D_interaction': h_interaction}
identification['survivors_after_candidate_expansion']=surviving(expanded,observations)
assert identification['survivors_after_candidate_expansion']==['D_interaction']

out={'scope': 'Hand-constructed algorithms and synthetic worlds; not an LLM evaluation, clinical evidence, or permanent runtime modification.',
     'search':results,'algorithm_relabel_checks':relabel_checks,'identification':identification}
(OUT/'results.json').write_text(json.dumps(out,indent=2))
for name,policies in results.items():
    print(name)
    for policy,r in policies.items():
        print(' ',policy,'success=',r['success'],'expansions=',r['expansions'],
              'detour=',r['detour_recruited'],'stop=',r['stop'])
print('Relabel checks:',relabel_checks,'all passed')
print('Identification:',json.dumps(identification,indent=2))
