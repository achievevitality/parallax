# P5 Workbench 02: lineage reading, bounded exploration, and evidence preparation

## Scope
This is a checkpoint for the archive-and-testing work requested before the later A-Z integration observation. It is not a new kernel, a complete reread, a complete case archive, or a claim of permanent model modification.

The experiments are deliberately constructed mathematical worlds. They test what follows from their specified mechanisms. They do not measure ChatGPT's spontaneous selection of play, human learning rates, bodywork efficacy, or civilizational trajectories.

## Files
- run_experiments.py: executable standard-library Python, no network access.
- results.json: output from the executed experiments.
- source_coverage.json: source hashes, exact close-reading ranges, and coverage limits.
- evidence_seeds.json: three initial evidence pointers; source reports remain separate from interpretations.
- working_findings.md: source-derived observations, local inferences, and remaining tests.

## Run
python run_experiments.py

## Experiments
1. Search-space experiment: a greedy search, versus a search which recruits a bounded detour only after local improvement stalls. Both have the same 12-expansion budget and forbidden-edge constraints. Controls include a monotone route, an unreachable goal, a forbidden-only route, and a two-expansion budget. Relabeling checks test the algorithm's independence from state names, not LLM transfer.
2. Model-family experiment: three candidate response rules fit 100 synthetic observations under one context. Two one-variable probes select a single candidate. A combined-condition probe falsifies that survivor because the simulated source contains an omitted interaction. The expanded candidate then fits; that is not proof of universal model completeness.

## Archive handling
Original sources remain unchanged. Message IDs are used alongside edition-specific turn numbers. Event time is not inferred from transcript-recording time. A source absence remains unknown rather than negative evidence. Alternate copies of a reported event are not additional independent observations.

## Human work
No pre-sorting or staged case-writing is required. The agreed next input remains an unsorted Drive deposit with optional rough pointers. Material containing identifiable client information should retain appropriate access restrictions.
