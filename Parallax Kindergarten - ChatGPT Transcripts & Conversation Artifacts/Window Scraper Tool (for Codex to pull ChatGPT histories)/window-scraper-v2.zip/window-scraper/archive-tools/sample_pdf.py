from pathlib import Path
from pypdf import PdfReader
from PIL import Image,ImageDraw
from concurrent.futures import ThreadPoolExecutor
import os,subprocess,sys,json
label=sys.argv[1];pdf=Path('archives')/label/'delivery'/f'{label}-conversation.pdf';d=PdfReader(pdf);folder=Path('tmp/pdfs')/(label+'-final');folder.mkdir(exist_ok=True)
for old in [*folder.glob('page-*.png'),*folder.glob('contact-*.jpg')]:old.unlink()
selected=set([1,2,3,len(d.pages)])
entries=json.loads((pdf.parent/f'{label}-conversation.json').read_text())['entries'];special=[e['id'] for e in entries if any(k in e['body'] for k in ['artifacts/','\\[','\\('])]
for i in range(0,len(d.pages),50):selected.add(i+1)
for i,p in enumerate(d.pages):
 t=p.extract_text() or ''
 if any(x in t for x in ['Torah as a living compression ecology','The current causal ecology','Country/group','FunctionSci-fi']):selected.add(i+1)
 if any(mid in t for mid in special):selected.update([i+1,min(i+2,len(d.pages))])
def render_sample(n):
 subprocess.run(['pdftoppm','-f',str(n),'-l',str(n),'-scale-to','1000','-png','-singlefile',str(pdf),str(folder/f'page-{n:04}')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
workers=max(1,min(4,int(os.environ.get('ARCHIVE_SAMPLE_WORKERS','4'))))
with ThreadPoolExecutor(max_workers=workers) as pool:list(pool.map(render_sample,sorted(selected)))
files=sorted(folder.glob('page-*.png'))
for k in range(0,len(files),12):
 im=Image.new('RGB',(1530,2040),'#c8ced4');draw=ImageDraw.Draw(im)
 for j,f in enumerate(files[k:k+12]):
  p=Image.open(f);p.thumbnail((500,480));x=j%3*510;y=j//3*510;im.paste(p,(x,y+20));draw.text((x+5,y+3),f.stem,fill='black')
 im.save(folder/f'contact-{k//12}.jpg')
print('Rendered',len(files),'sample pages with',workers,'workers')
