from pathlib import Path
from pypdf import PdfReader
from pypdf._text_extraction import mult
import json,sys
label=sys.argv[1];root=Path('archives')/label/'delivery';reader=PdfReader(root/f'{label}-conversation.pdf');found=[]
for i,page in enumerate(reader.pages):
 def visit(t,cm,tm,font,size):
  y=mult(tm,cm)[5]
  if t.strip() and font and font.get('/Subtype')=='/Type3' and y<45:
   found.append({'page':i+1,'text':t,'pdf_y':y,'tm_y':tm[5]})
 page.extract_text(visitor_text=visit)
(root/'page-fragment-candidates.json').write_text(json.dumps(found,ensure_ascii=False,indent=2));print(json.dumps(found,ensure_ascii=False,indent=2))
