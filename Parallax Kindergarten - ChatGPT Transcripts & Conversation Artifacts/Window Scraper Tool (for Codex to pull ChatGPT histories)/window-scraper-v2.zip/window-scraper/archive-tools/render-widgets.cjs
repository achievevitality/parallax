const fs=require('fs'),path=require('path');
const {chromium}=require('/Users/brendamathisen/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const label=process.argv[2];if(!/^[A-Za-z0-9-]+$/.test(label))throw Error('Invalid label');
 const root=path.resolve(__dirname,'../archives',label,'delivery');const widgets=JSON.parse(fs.readFileSync(path.join(root,'artifacts/artifact-index.json'))).embedded_widgets||[];
 const browser=await chromium.launch({headless:true,executablePath:process.env.ARCHIVE_CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--disable-extensions','--no-first-run','--disable-background-networking']});
 const context=await browser.newContext({viewport:{width:1100,height:800},colorScheme:'light'});await context.route(/^https?:/,r=>r.abort());const page=await context.newPage();
 for(const w of widgets){await page.goto('file://'+path.join(root,w.path));await page.screenshot({path:path.join(root,w.preview),fullPage:true});console.log(JSON.stringify({path:w.preview,title:w.title,buttons:await page.locator('button').allTextContents()}));}
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
