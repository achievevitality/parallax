const fs = require('fs');
const path = require('path');
const deps=process.env.ARCHIVE_NODE_MODULES || require('os').homedir()+'/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules';
const {chromium}=require(deps+'/playwright');
const {marked}=require(deps+'/marked');
const katex=require('./vendor/katex/dist/katex.js');
const katexRoot=path.join(__dirname,'vendor/katex/dist');
const mathCss=fs.readFileSync(path.join(katexRoot,'katex.min.css'),'utf8').replace(/url\(([^)]+)\)/g,(_,u)=>'url(file://'+path.join(katexRoot,u.replace(/[\"\']/g,''))+')');
const label=process.argv[2]||'P4';
if(!/^[A-Za-z0-9-]+$/.test(label))throw Error('Invalid label');
const root=path.resolve(__dirname,'../archives/'+label+'/delivery');
const css=`
@page{size:Letter;margin:0.7in 0.65in 0.7in}
*{box-sizing:border-box}
body{font-family:Arial,"Apple Color Emoji",sans-serif;font-size:10.5pt;line-height:1.48;color:#18202b;margin:0;overflow-wrap:anywhere}
h1{font-size:25pt;line-height:1.15;color:#153a4c;margin:0 0 20pt}
h2{font-size:16pt;line-height:1.3;margin:20pt 0 10pt;break-after:avoid}
h3{font-size:13pt;line-height:1.3;margin:17pt 0 8pt;break-after:avoid}
h4,h5,h6{font-size:11pt;margin:12pt 0 6pt;break-after:avoid}
p{margin:0 0 10pt;orphans:3;widows:3}
blockquote{border-left:3px solid #93b1bf;margin:12pt 0;padding:3pt 0 3pt 13pt;color:#274251}
blockquote p:last-child{margin:0}
li{margin-bottom:5pt}ul,ol{padding-left:22pt}
pre{font-size:8pt;white-space:pre-wrap;overflow-wrap:anywhere;background:#f2f5f6;padding:10pt}
code{font-family:Menlo,monospace;font-size:9pt;overflow-wrap:anywhere}
table{border-collapse:collapse;width:100%;font-size:9pt;table-layout:fixed}th,td{border:1px solid #c5cdd3;padding:7pt;overflow-wrap:anywhere}tr{break-inside:avoid}
a{color:#176582;text-decoration:underline;overflow-wrap:anywhere}
img{display:block;max-width:100%;max-height:5in;object-fit:contain;margin:12pt auto}
.entry{border-top:1px solid #cbd6dd;padding-top:14pt;margin-top:22pt}
.entry-label{font-size:11pt;font-weight:bold;color:#153a4c;break-after:avoid;margin-bottom:4pt}
.entry-meta{font-size:7.5pt;color:#586876;margin-bottom:13pt;overflow-wrap:anywhere;break-after:avoid}
.cover{break-after:page;padding-top:50pt}
.cover p{font-size:12pt;line-height:1.6}
.cover .small{font-size:10pt;color:#586876}
.user{background:#f5f8fa;padding:14pt}
hr{border:0;border-top:1px solid #cbd6dd;margin:18pt 0}
`;
function esc(s){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;')}
function markdown(s){
 const formulas=[];
 function token(tex,display){const index=formulas.length;const rendered=katex.renderToString(tex.replace(/,\s*(?=\\text)/g,',\\allowbreak '),{displayMode:display,output:'html',throwOnError:true,trust:false});formulas.push('<'+(display?'div':'span')+' class="math-'+(display?'block':'inline')+'" data-tex="'+esc(tex)+'">'+rendered+'</'+(display?'div':'span')+'>');return (display?'\n\n':'')+'MATHPLACEHOLDER'+index+'END'+(display?'\n\n':'');}
 s=s.replace(/\\\[([\s\S]*?)\\\]/g,(_,t)=>token(t,true)).replace(/\\\(([\s\S]*?)\\\)/g,(_,t)=>token(t,false));
 return marked.parse(s,{gfm:true,breaks:false}).replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,'').replace(/MATHPLACEHOLDER(\d+)END/g,(_,i)=>formulas[Number(i)]);
}
function document(title,body){return '<!doctype html><html><head><meta charset="UTF-8"><title>'+esc(title)+'</title><style>'+mathCss+css+'.katex-display > .katex{white-space:normal}.katex{font-size:1.05em}.math-block{break-inside:avoid;margin:12pt 0}.math-inline{display:inline-block;max-width:100%;vertical-align:middle}img.math-snapshot{display:inline-block;max-height:none;margin:0;vertical-align:middle}.math-block img.math-snapshot{display:block;margin:auto}'+ '</style></head><body>'+body+'</body></html>'}
async function main(){
 const browser=await chromium.launch({headless:true,executablePath:process.env.ARCHIVE_CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--disable-extensions','--no-first-run','--disable-background-networking']});
 const context=await browser.newContext({javaScriptEnabled:false,viewport:{width:692,height:900},deviceScaleFactor:3});
 await context.route(/^https?:/,r=>r.abort());
 const page=await context.newPage();
 let e=JSON.parse(fs.readFileSync(path.join(root,label+'-conversation.json'),'utf8')).entries;
 const audit=JSON.parse(fs.readFileSync(path.join(root,'capture-audit.json')));
 const body='<section class="cover"><h1>'+label+'<br>Conversation archive</h1><p>'+esc(JSON.parse(fs.readFileSync(path.join(root,'capture-audit.json'))).captured_at || 'See capture audit')+'</p><p>'+audit.active_branch_user_messages+' user prompts · '+e.length+' conversation and progress messages</p><p>This edition preserves the saved conversation text, with citations resolved and attachments identified. When extending an existing transcript, earlier entries are retained and any earlier-branch entries are explicitly marked.</p><p class="small">The accompanying original JSON is the preservation master: it includes the full returned message graph, alternate branches, tool records, timestamps, and source metadata.</p><p class="small">Source: chatgpt.com/c/'+audit.source_conversation_id+'<br>Snapshot follows the endpoint recorded in capture-audit.json.<br>No conversation text has been summarized.</p></section>'+
 e.map(x=>'<section class="entry '+(x.role==='user'?'user':'assistant')+'" id="message-'+esc(x.id)+'"><div class="entry-label">'+String(x.number).padStart(3,'0')+' · '+esc(x.role==='user'?(JSON.parse(fs.readFileSync(path.resolve(root,'../../..','capture-config.json'))).user_display_name||'User'):'ChatGPT')+(x.display_kind==='generated_image'?' · Generated image':x.channel==='commentary'?' · Progress':'')+'</div><div class="entry-meta">'+esc(x.timestamp)+'<br>'+esc(x.id)+'</div>'+(x.archive_note?'<p><strong>Archive note:</strong> '+esc(x.archive_note)+'</p>':'')+markdown(x.body)+'</section>').join('\n');
 const jobs=[{html:path.join(root,label+'-conversation.html'),pdf:path.join(root,label+'-conversation.pdf'),title:label+' conversation',body}];
 for(const f of (process.argv.includes('--artifacts')?fs.readdirSync(path.join(root,'artifacts')).filter(f=>f.endsWith('.md')):[])){
   const md=fs.readFileSync(path.join(root,'artifacts',f),'utf8');
   jobs.push({html:path.join(root,'artifacts',f.replace(/\.md$/,'.html')),pdf:path.join(root,'artifacts',f.replace(/\.md$/,'.pdf')),title:f.replace(/\.md$/,''),body:markdown(md)});
 }
 let stats=[];
 for(const job of jobs){
   fs.writeFileSync(job.html,document(job.title,job.body));
   await page.goto('file://'+job.html,{waitUntil:'load'});
   await page.evaluate(()=>document.fonts.ready);
   const math=page.locator('.math-block, .math-inline');const mathCount=await math.count();const mathIndex=[];
   if(mathCount){
    fs.mkdirSync(path.join(root,'artifacts/equations'),{recursive:true});
    for(let i=0;i<mathCount;i++){
     const loc=math.nth(i);const name='artifacts/equations/equation-'+String(i+1).padStart(3,'0')+'.png';
     const info=await loc.evaluate(el=>({tex:el.getAttribute('data-tex'),width:el.getBoundingClientRect().width,height:el.getBoundingClientRect().height}));
     const overflow=await loc.evaluate(el=>{const box=el.getBoundingClientRect();return [...el.querySelectorAll('.base')].some(x=>{const r=x.getBoundingClientRect();return r.right>box.right+2||r.left<box.left-2;});});
     if(overflow)throw Error('Equation extends outside readable area: '+name);
     await loc.screenshot({path:path.join(root,name)});
     await loc.evaluate((el,args)=>{const img=document.createElement('img');img.src=args.src;img.alt='Equation';img.className='math-snapshot';img.style.width=args.width+'px';img.style.height=args.height+'px';el.replaceChildren(img);},{src:'file://'+path.join(root,name),width:info.width,height:info.height});
     mathIndex.push({path:name,...info});
    }
    fs.writeFileSync(path.join(root,'artifacts/equations/index.json'),JSON.stringify(mathIndex,null,2));
    fs.writeFileSync(job.html,(await page.content()).replaceAll('file://'+root+'/',''));
   }
   await page.pdf({path:job.pdf,format:'Letter',printBackground:true,displayHeaderFooter:true,headerTemplate:'<span></span>',footerTemplate:'<div style="font:8px Arial;width:100%;text-align:center;color:#64717a">'+label+' archive · <span class="pageNumber"></span> / <span class="totalPages"></span></div>',preferCSSPageSize:true,tagged:true,outline:true});
   const check=await page.evaluate(()=>({text:document.body.innerText.length,entries:document.querySelectorAll('.entry').length,brokenImages:[...document.images].filter(i=>!i.complete||i.naturalWidth===0).map(i=>i.src)}));
   stats.push({file:path.relative(root,job.pdf),bytes:fs.statSync(job.pdf).size,...check});
   console.log(JSON.stringify(stats[stats.length-1]));
 }
 fs.writeFileSync(path.join(root,'render-checks.json'),JSON.stringify(stats,null,2));
 await browser.close();
}
main().catch(e=>{console.error(e);process.exit(1)});
