from pathlib import Path
from PIL import Image
import json,re,hashlib
import sys
for label in sys.argv[1:]:
 root=Path('archives')/label;dest=root/'delivery';data=json.loads((root/'raw-source.json').read_text());art=dest/'artifacts';images={};attachments=[];links=[]
 def walk(v):
  if isinstance(v,dict):
   if v.get('content_type')=='image_asset_pointer':images[v['asset_pointer'].split('/')[-1]]=v
   for child in v.values():walk(child)
  elif isinstance(v,list):
   for child in v:walk(child)
 walk(data)
 recovered=json.loads((root/'image-recovery.json').read_text()) if (root/'image-recovery.json').exists() else []
 saved={x['file_id']:x['path'] for x in recovered if x.get('ok')}
 for n in data['mapping'].values():
  m=n.get('message')
  if not m:continue
  for a in m.get('metadata',{}).get('attachments',[]):attachments.append({'message_id':m['id'],'source_attachment':a,'recovered_path':saved.get(a.get('id')),'status':'recovered as served' if a.get('id') in saved else 'reference only; original file bytes not in this package'})
  for part in m['content'].get('parts',[]):
   if isinstance(part,str):
    for uri in re.findall(r'sandbox:[^\s)\]<>"\u201d]+',part):links.append({'message_id':m['id'],'uri':uri,'status':'source link retained; external file bytes not recovered'})
 (art/'file-reference-index.json').write_text(json.dumps({'scope':'Attachment metadata and sandbox download links in the full returned graph. References are not binary file copies. Generated library files may also be identified within tool records in the preservation master.','attachments':attachments,'sandbox_links':links},ensure_ascii=False,indent=2))
 manifest=[]
 for item in recovered:
  if not item.get('ok'):continue
  p=dest/item['path'];source=images.get(item['file_id'],{});im=Image.open(p);im.verify();actual=Image.open(p).size
  manifest.append({'file_id':item['file_id'],'path':item['path'],'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'saved_dimensions':actual,'source_declared_dimensions':[source.get('width'),source.get('height')],'source_declared_bytes':source.get('size_bytes'),'preservation':'Unmodified bytes served by ChatGPT. Different byte counts or dimensions mean original-upload binary identity is not established.'})
 (art/'image-preservation-audit.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));print(label,len(attachments),'attachment references,',len(links),'sandbox links,',len(manifest),'saved conversation images; dimension differences',sum(x['saved_dimensions']!=tuple(x['source_declared_dimensions']) for x in manifest))
