from pathlib import Path
from pypdf import PdfReader
from lxml import html
import json,re,unicodedata,difflib,sys,collections,copy
label=sys.argv[1];r=Path('archives')/label/'delivery';pdf=PdfReader(r/f'{label}-conversation.pdf');pages=[p.extract_text() or '' for p in pdf.pages];text=re.sub(label+r' archive\s*·\s*\d+\s*/\s*\d+','','\n'.join(pages));norm=lambda s:re.sub(r'[\s\ufe0e\ufe0f]','',unicodedata.normalize('NFKC',s).replace('‐','-'));text=norm(text);tree=html.parse(str(r/f'{label}-conversation.html'));sections=tree.xpath('//section[contains(@class,"entry ")]');changes=[];failures=[]
for ix,s in enumerate(sections):
 expected=norm(s.text_content());mid=s.attrib['id'][8:];prefix=expected[:expected.index(mid)+len(mid)];a=text.find(prefix)
 if a<0:failures.append({'id':mid,'error':'message header missing'});continue
 end=text.find(norm(sections[ix+1].text_content())[:30],a+1) if ix+1<len(sections) else len(text);actual=text[a:end]
 if expected!=actual:
  numbered=copy.deepcopy(s)
  for ol in numbered.xpath('.//ol'):
   start=int(ol.attrib.get('start','1'))
   for i,li in enumerate(ol.xpath('./li')):li.text=str(start+i)+'.'+(li.text or '')
  if norm(numbered.text_content())==actual:
   changes.append({'id':mid,'difference':'Generated ordered-list markers only'});continue
  dd=[(tag,expected[b:c],actual[d:f]) for tag,b,c,d,f in difflib.SequenceMatcher(None,expected,actual,autojunk=False).get_opcodes() if tag!='equal']
  expected_markers=[]
  for ol in s.xpath('.//ol'):
   start=int(ol.attrib.get('start','1'));expected_markers.extend(str(start+i)+'.' for i,_ in enumerate(ol.xpath('./li')))
  inserts=[b for tag,a,b in dd if tag=='insert' and not a]
  extra=collections.Counter(actual);extra.subtract(collections.Counter(expected));extra.subtract(collections.Counter(''.join(expected_markers)))
  headers=[collections.Counter(norm(h.text_content())) for h in s.xpath('.//thead')]
  def match_headers(rem,hs):
   if any(v<0 for v in rem.values()):return False
   rem=+rem
   if not rem:return True
   if not hs:return False
   h=hs[0]
   for count in range(20):
    trial=rem.copy();trial.subtract({k:v*count for k,v in h.items()})
    if match_headers(trial,hs[1:]):return True
   return False
  allowed=all(tag=='insert' and not a for tag,a,b in dd) and match_headers(extra,headers)
  record={'id':mid,'differences':dd,'list_markers':expected_markers}
  (changes if allowed else failures).append(record)
result={'pages':len(pages),'messages':len(sections),'sparse_pages':[i+1 for i,t in enumerate(pages) if len(t)<70],'full_text_mismatches':failures,'formatting_only_differences':changes,'normalization':'Whitespace, Unicode compatibility normalization and emoji presentation selectors. Generated list markers checked separately.','null_characters':sum(x.count(chr(0)) for x in pages),'private_use_characters':sum(0xe000<=ord(c)<=0xf8ff for x in pages for c in x)}
(r/'full-pdf-text-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ('full_text_mismatches','formatting_only_differences')},indent=2));print('Mismatches',len(failures),'formatting differences',len(changes));print(json.dumps(failures,ensure_ascii=False)[:8000])
