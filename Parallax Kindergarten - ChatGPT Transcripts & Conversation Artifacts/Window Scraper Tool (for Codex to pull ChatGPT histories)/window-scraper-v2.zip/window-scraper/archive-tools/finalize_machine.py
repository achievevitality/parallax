from pathlib import Path
import json,hashlib,shutil,collections,zipfile,datetime,sys
label=sys.argv[1];assert __import__('re').fullmatch(r'[A-Za-z0-9-]+',label);root=Path(__file__).resolve().parents[1]/'archives'/label;src=root/'delivery';out=root/'machine-readable';out.mkdir(exist_ok=True)
def strict(pairs):
 d={}
 for k,v in pairs:
  assert k not in d,('duplicate key',k)
  d[k]=v
 return d
raw=(src/f'{label}-original-source.json').read_bytes();data=json.loads(raw,object_pairs_hook=strict);graph=data['mapping'];assert raw==(root/'raw-source.json').read_bytes()
rows=[json.loads(line,object_pairs_hook=strict) for line in (src/f'{label}-all-records.jsonl').read_text().split('\n') if line];assert len(rows)==len(graph);assert {n['id']:n for n in rows}==graph
roots=[k for k,v in graph.items() if v['parent'] is None];assert roots
seen=set();stack=roots[:]
while stack:
 k=stack.pop();assert k not in seen;seen.add(k);node=graph[k];assert node['id']==k
 if node['parent'] is not None:assert k in graph[node['parent']]['children']
 for child in node['children']:assert graph[child]['parent']==k
 stack.extend(node['children'])
assert seen==set(graph)
active=[];current=data['current_node']
while current:active.append(current);current=graph[current]['parent']
active.reverse()
for name in [f'{label}-original-source.json',f'{label}-all-records.jsonl',f'{label}-conversation.json',f'{label}-conversation.md',f'{label}-all-content.md']:shutil.copy2(src/name,out/name)
metadata={k:v for k,v in data.items() if k!='mapping'};(out/f'{label}-conversation-metadata.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
reconstructed=json.loads((out/f'{label}-conversation-metadata.json').read_text());reconstructed['mapping']={n['id']:n for n in rows};assert reconstructed==data
chunks=out/'records';chunks.mkdir(exist_ok=True);chunk_index=[]
for i in range(0,len(rows),64):
 part=rows[i:i+64];name=f'records/records-{i//64+1:03}.jsonl';(out/name).write_text(''.join(json.dumps(n,ensure_ascii=False)+'\n' for n in part));chunk_index.append({'path':name,'count':len(part),'node_ids':[n['id'] for n in part]})
reloaded=[json.loads(line) for c in chunk_index for line in (out/c['path']).read_text().split('\n') if line];assert reloaded==rows
index={'source_conversation_id':data['conversation_id'],'current_node':data['current_node'],'active_branch_node_ids_in_conversation_order':active,'all_node_ids_in_source_order':list(graph),'chunks':chunk_index,'note':'Source order is not chronological order. Follow parent/children links or the active branch list. Preserve tool records and all metadata when transforming.'};(out/f'{label}-record-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2))
allmd=(out/f'{label}-all-content.md').read_text();pos=0
for i,n in enumerate(rows,1):
 m=n.get('message')
 if not m:continue
 content=f'## Record {i} · {m["author"]["role"]} · {m["id"]}\n\n'+json.dumps(m['content'],ensure_ascii=False,indent=2);pos=allmd.index(content,pos)+len(content)
entries=json.loads((out/f'{label}-conversation.json').read_text())['entries'];selected=[graph[k]['message'] for k in active if graph[k].get('message') and graph[k]['message']['author']['role'] in ('user','assistant') and graph[k]['message']['content']['content_type'] in ('text','multimodal_text') and graph[k]['message'].get('recipient','all')=='all' or graph[k].get('message') and graph[k]['message'].get('metadata',{}).get('image_gen_title')]
if (src/'reading-view-index.json').exists():
 extension=json.loads((src/'reading-view-index.json').read_text()); prior=extension['prior_entry_ids']; expected=prior+[m['id'] for m in selected if m['id'] not in set(prior)];assert expected==extension['reading_entry_ids'];assert set(extension['retained_earlier_branch_ids'])==set(prior)-{m['id'] for m in selected}; selected=[graph[k]['message'] for k in expected]
 for name in ('reading-view-index.json','update-verification.json'):shutil.copy2(src/name,out/name)
assert [m['id'] for m in selected]==[e['id'] for e in entries]
md=(out/f'{label}-conversation.md').read_text()
for m,e in zip(selected,entries):
 assert e['source_text']=='\n'.join(p for p in m['content'].get('parts',[]) if isinstance(p,str));assert e['source_content']==m['content'];assert e['role']==m['author']['role'];assert e['timestamp']==datetime.datetime.fromtimestamp(m['create_time'],datetime.timezone.utc).isoformat();assert e['body'] in md
art=out/'artifacts';art.mkdir(exist_ok=True)
readable=out/'readable-parts';readable.mkdir(exist_ok=True);reading_index=[];batch=[];length=0
def save_part():
 if not batch:return
 name=f'readable-parts/{label}-part-{len(reading_index)+1:03}.md'
 text='\n\n'.join(f'## {e["number"]:03} · {e["role"]}\n\n{e["timestamp"]} · Message {e["id"]}\n\n{e["body"]}' for e in batch)
 (out/name).write_text(text)
 reading_index.append({'path':name,'message_ids':[e['id'] for e in batch],'characters':len(text)})
for e in entries:
 if batch and length+len(e['body'])>150000:save_part();batch=[];length=0
 batch.append(e);length+=len(e['body'])
save_part();assert [mid for p in reading_index for mid in p['message_ids']]==[e['id'] for e in entries]
(out/f'{label}-reading-index.json').write_text(json.dumps(reading_index,ensure_ascii=False,indent=2))
for p in (src/'artifacts').rglob('*'):
 if p.is_file() and p.suffix not in ('.pdf',):
  dest=art/p.relative_to(src/'artifacts');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
sha=hashlib.sha256(raw).hexdigest()
audit={'status':'Complete for the captured source object','source_current_node':data['current_node'],'last_readable_message_id':entries[-1]['id'],'source_bytes':len(raw),'source_sha256':sha,'nodes':len(rows),'message_records':sum(n.get('message') is not None for n in rows),'active_branch_nodes':len(active),'nodes_outside_active_branch':len(graph)-len(active),'readable_messages':len(entries),'record_chunks':len(chunk_index),'checks':{'strict_json_no_duplicate_keys':True,'original_capture_byte_identical':True,'jsonl_every_node_and_field_equal':True,'metadata_plus_jsonl_reconstructs_entire_source_object':True,'all_chunk_records_equal_source_order_and_values':True,'every_node_reachable_no_cycles':True,'every_parent_child_link_reciprocal':True,'all_content_markdown_contains_every_content_object_unchanged':True,'readable_view_ids_order_source_text_speakers_timestamps_match':True,'readable_markdown_contains_every_display_body':True},'limits':'Complete relative to the captured returned object. Later live messages, deleted/unreturned data, and binary contents of externally linked files are not implied by source-record completeness. Readable Markdown is the active conversation view, not the full metadata archive.'};(out/f'{label}-machine-verification.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
(out/'READ-ME-FIRST.md').write_text(f'''# {label} — Machine-readable archive

Start with **{label}-conversation.md** to read the saved conversation (including explicitly marked earlier entries retained from an existing transcript): {len(entries)} entries covering user messages, assistant replies, progress messages, and any generated images, with speakers, UTC timestamps, formatting, and emojis. **{label}-conversation.json** pairs the readable view with exact original source text and complete content objects.

Use **{label}-original-source.json** for complete archival processing. It preserves the exact captured bytes and every returned field, including {len(rows)} graph nodes, {audit['message_records']} message records, alternate branches, tool records, original content types, timestamps, and metadata. This is the preservation master.

**{label}-all-records.jsonl** contains one complete graph node per line. The **records/** directory contains the same nodes in {len(chunk_index)} smaller files without splitting nodes. **{label}-record-index.json** lists chunks and the active branch in conversation order. Source file order is not conversation order.

**{label}-conversation-metadata.json** retains every top-level field except mapping. Combining it with the JSONL nodes keyed by id reconstructs the entire original JSON object. This round-trip was verified. Keep the original JSON for exact byte fidelity.

**{label}-all-content.md** retains every original message content object as an additional reading aid. Full metadata remains in the original JSON and JSONL files.

**readable-parts/** contains the same active conversation split at message boundaries for smaller uploads. Read in numbered order; **{label}-reading-index.json** records every message ID in each part. Relative artifact links in these parts resolve against the archive root.

**artifacts/** contains written blocks and embedded visuals recovered from the source. Equations appear as images in the PDF, while their complete original TeX remains in the conversation files and equations/index.json. Recovered images preserve unmodified bytes served by ChatGPT; this does not establish byte identity with an original upload that ChatGPT may have re-encoded. File links and attachment metadata do not themselves include external file bytes; consult artifact-index.json and file-reference-index.json for recovered items and references.

The source snapshot ends at node **{data['current_node']}**, and the last readable message is **{entries[-1]['id']}**. Later live changes and data not returned by ChatGPT are outside this snapshot. Readable Markdown is not the full metadata archive.

**{label}-machine-verification.json** records source, graph, field, ordering, timestamp, and reconstruction checks. **SHA256SUMS.json** records checksums for every other package file.
''')
files=sorted(p for p in out.rglob('*') if p.is_file() and p.name!='SHA256SUMS.json');manifest={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files};(out/'SHA256SUMS.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
zip_path=root/f'{label}-machine-readable-FINAL.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(out.rglob('*')):
  if p.is_file():z.write(p,f'{label}-machine-readable/'+str(p.relative_to(out)))
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 for name,expected in manifest.items():assert hashlib.sha256(z.read(f'{label}-machine-readable/'+name)).hexdigest()==expected['sha256']
result={'package':str(zip_path),'bytes':zip_path.stat().st_size,'sha256':hashlib.sha256(zip_path.read_bytes()).hexdigest(),'files':len(manifest)+1,'audit':audit};(root/'machine-package-manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
