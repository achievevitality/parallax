from pathlib import Path
import json,sys
label=sys.argv[1];root=Path('archives')/label;dest=root/'delivery';old=json.loads(Path(sys.argv[2]).read_text())['entries'];current=json.loads((dest/f'{label}-conversation.json').read_text());new=current['entries'];raw=json.loads((root/'raw-source.json').read_text());oldids={e['id'] for e in old};newids={e['id'] for e in new};lookup={e['id']:e for e in new};entries=[]
for e in old:
 m=raw['mapping'][e['id']]['message'];assert e['source_text']=='\n'.join(p for p in m['content'].get('parts',[]) if isinstance(p,str))
 entry=dict(lookup.get(e['id'],e));entry['source_content']=m['content']
 if e['id'] not in newids:entry['archive_note']='Retained from the existing transcript. This message now belongs to an earlier branch of the conversation.'
 entries.append(entry)
entries.extend(e for e in new if e['id'] not in oldids)
for i,e in enumerate(entries,1):e['number']=i
current['entries']=entries;current['reading_view']='Existing transcript preserved in order, followed by newly captured active-path entries. Earlier-branch entries are explicitly identified.'
(dest/f'{label}-conversation.json').write_text(json.dumps(current,ensure_ascii=False,indent=2));md=f'# {label} — Updated conversation transcript\n\n'+current['reading_view']+'\n\n'
md+='\n\n'.join(f'## {e["number"]:03} · {e["role"].title()}\n\n{e["timestamp"]} · Message {e["id"]}\n\n'+('**Archive note:** '+e['archive_note']+'\n\n' if e.get('archive_note') else '')+e['body'] for e in entries);(dest/f'{label}-conversation.md').write_text(md)
index={'prior_entry_ids':[e['id'] for e in old],'retained_earlier_branch_ids':[e['id'] for e in old if e['id'] not in newids],'reading_entry_ids':[e['id'] for e in entries]};(dest/'reading-view-index.json').write_text(json.dumps(index,indent=2));audit=json.loads((dest/'capture-audit.json').read_text());audit['readable_messages']=len(entries);(dest/'capture-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2));report={'prior_readable_entries':len(old),'updated_readable_entries':len(entries),'added_readable_entries':len(entries)-len(old),'prior_ids_are_exact_prefix':True,'prior_source_text_unchanged':True,'retained_earlier_branch_entries':index['retained_earlier_branch_ids'],'publication':'Update the existing P4 Drive files in place, keeping their IDs and links.'};(dest/'update-verification.json').write_text(json.dumps(report,indent=2));print(report)
