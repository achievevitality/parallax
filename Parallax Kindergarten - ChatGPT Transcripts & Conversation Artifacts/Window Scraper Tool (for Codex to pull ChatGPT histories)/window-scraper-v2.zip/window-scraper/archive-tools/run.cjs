const fs=require('fs'),path=require('path'),cp=require('child_process'),os=require('os');
const root=path.resolve(__dirname,'..'),configPath=path.join(root,'capture-config.json');
const config=JSON.parse(fs.readFileSync(configPath));const [op,...labels]=process.argv.slice(2);
const python=process.env.ARCHIVE_PYTHON || path.join(os.homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3');
const operations={prepare:'prepare_archive.py',render:'render_archive.cjs',widgets:'render-widgets.cjs',audit:'audit_pdf.py',sample:'sample_pdf.py',machine:'finalize_machine.py',pdf:'finalize_pdf.py',inventory:'inventory-assets.py'};
if(!labels.length || labels.some(l=>!config.conversations[l] || !/^[A-Za-z0-9-]+$/.test(l)))throw Error('Use configured labels');
for(const label of labels){const dir=path.join(root,'archives',label);fs.mkdirSync(dir,{recursive:true});
if(op==='capture'){if(fs.existsSync(path.join(dir,'raw-source.json')))throw Error('Use a staging directory when updating; preserve the existing reading view for extend-existing.py');cp.execFileSync('/usr/bin/osascript',['-l','JavaScript',path.join(__dirname,'capture-source.jxa'),config.conversations[label],dir,configPath],{cwd:root,stdio:'inherit',timeout:600000});}
else{const file=operations[op];if(!file)throw Error('Unknown operation');cp.execFileSync(file.endsWith('.py')?python:process.execPath,[path.join(__dirname,file),label],{cwd:root,stdio:'inherit',timeout:3600000});}}
