import json,re,hashlib,shutil,datetime,collections,sys
from pathlib import Path
from urllib.parse import urlparse

label=sys.argv[1] if len(sys.argv)>1 else "P4"
assert __import__("re").fullmatch(r"[A-Za-z0-9-]+",label)
root=Path(__file__).resolve().parents[1]/"archives"/label
out=root/"delivery";out.mkdir(exist_ok=True)
art=out/"artifacts";art.mkdir(exist_ok=True)
data=json.loads((root/"raw-source.json").read_text())
mp=data["mapping"]; branch=[];cur=data["current_node"];seen=set()
while cur:
    assert cur not in seen and cur in mp
    seen.add(cur);branch.append(mp[cur]);cur=mp[cur]["parent"]
branch.reverse()
shutil.copy2(root/"raw-source.json",out/f"{label}-original-source.json")
nodes=list(mp.values())
with (out/f"{label}-all-records.jsonl").open("w") as f:
    for n in nodes:f.write(json.dumps(n,ensure_ascii=False)+"\n")
messages=[n["message"] for n in branch if n.get("message")]
selected=[m for m in messages if m["author"]["role"] in ("user","assistant") and m["content"]["content_type"] in ("text","multimodal_text") and m.get("recipient","all")=="all" or bool(m.get("metadata",{}).get("image_gen_title"))]
assets=[];written=[];entries=[];widgets=[]
recovery={a["file_id"]:a for a in json.loads((root/"image-recovery.json").read_text()) if a.get("ok")} if (root/"image-recovery.json").exists() else {}
image_records=[]
def stamp(t):
    return datetime.datetime.fromtimestamp(t,datetime.timezone.utc).isoformat() if t else "Timestamp not supplied"
def readable(m,text):
    for ref in m.get("metadata",{}).get("content_references",[]):
        token=ref.get("matched_text")
        if not token:continue
        alt=ref.get("alt")
        if ref.get("type")=="file":
            name=ref.get("name","Referenced file")
            if "6a8ccd63" in name:name="P1 transcript"
            elif "6a960565" in name:name="P2 transcript"
            point=ref.get("input_pointer") or {}
            if point.get("line_range_start"):
                name+=f' · lines {point["line_range_start"]}-{point.get("line_range_end",point["line_range_start"])}'
            url=ref.get("cloud_doc_url")
            alt="(["+name+"]("+url+"))" if url else "["+name+"; source record retained in original JSON]"
        if ref.get("type")=="hidden":
            alt="[Source reference unavailable in original]" if ref.get("invalid") else "[Conversation-context reference]"
        if ref.get("type")=="client_defined_widget" and isinstance(ref.get("data"),dict):
            wd=ref["data"];content=wd.get("content");title=wd.get("title","Interactive visual")
            if isinstance(content,str) and wd.get("language")=="html":
                stem="widget-"+m["id"]
                (art/(stem+".html")).write_text(content)
                widgets.append({"title":title,"path":"artifacts/"+stem+".html","preview":"artifacts/"+stem+".png","message_id":m["id"],"source":"Exact embedded widget HTML"})
                alt="\n\n**"+title+"**\n\n!["+title+"](artifacts/"+stem+".png)\n\n[Interactive original](artifacts/"+stem+".html)\n\n"
        if ref.get("type")=="dil":
            try:
                payload=json.loads(token.split("\ue202",1)[1].rstrip("\ue201"));labels=[]
                def find_labels(x):
                    if isinstance(x,dict):
                        for k,v in x.items():
                            if k=="label" and isinstance(v,str):labels.append(v)
                            else:find_labels(v)
                    elif isinstance(x,list):
                        for v in x:find_labels(v)
                find_labels(payload)
                alt="[Suggested action: "+"; ".join(labels)+"]" if labels else "[Interactive control; original definition retained in source JSON]"
            except (ValueError,IndexError):pass
        if ref.get("type") in ("image_v2","image_group"):
            ims=[]
            for im in ref.get("images",[]):
                im=im.get("image_result",im)
                url=im.get("content_url") or im.get("original_content_url")
                if not url:continue
                name="image-"+hashlib.sha256(url.encode()).hexdigest()[:12]+".jpg"
                assets.append({"url":url,"path":"artifacts/"+name,"title":im.get("title","Image"),"source":im.get("url"),"original_url":im.get("original_content_url"),"kind":"Referenced image, not AI-created"})
                ims.append("!["+im.get("title","Image")+"](artifacts/"+name+")")
            if ims:alt="\n".join(ims)
        if alt:text=text.replace(token,alt)
        elif ref.get("safe_urls"):
            text=text.replace(token," ("+", ".join("[Source]("+u+")" for u in ref["safe_urls"])+")")
    text=re.sub(r":::writing\{[^\n]*\}\n","",text)
    text=re.sub(r"(?m)^:::\s*$","",text)
    return text
for index,m in enumerate(selected,1):
    text="\n".join(p for p in m["content"].get("parts",[]) if isinstance(p,str))
    for j,match in enumerate(re.finditer(r':::writing\{([^\n]+)\}\n(.*?)\n:::',text,re.S),1):
        attrs=dict(re.findall(r'(\w+)="([^"]*)"',match.group(1)))
        title=attrs.get("title","Written artifact")
        name=f'{len(written)+1:02d}-'+re.sub(r'[^a-zA-Z0-9]+','-',title).strip('-')+'.md'
        (art/name).write_text(match.group(2)+"\n")
        written.append({"title":title,"path":"artifacts/"+name,"message_id":m["id"],"writing_id":attrs.get("id"),"created_at":stamp(m.get("create_time")),"verbatim_body":True})
    attachments=m.get("metadata",{}).get("attachments",[])
    body_parts=[]
    if m.get("metadata",{}).get("image_gen_title"):body_parts.append("**Generated image: "+m["metadata"]["image_gen_title"]+"**")
    for part in m["content"].get("parts",[]):
        if isinstance(part,str):body_parts.append(readable(m,part))
        elif part.get("content_type")=="image_asset_pointer":
            file_id=part["asset_pointer"].removeprefix("sediment://");record=recovery.get(file_id)
            if not record:raise ValueError("Image not yet recovered: "+file_id)
            title=m.get("metadata",{}).get("image_gen_title") or next((a.get("name") for a in attachments if a.get("id")==file_id),"Uploaded image")
            body_parts.append("!["+title+"]("+record["path"]+")")
            image_records.append({"file_id":file_id,"path":record["path"],"title":title,"message_id":m["id"],"kind":"Generated image" if m["author"]["role"]=="tool" else "User-uploaded image","source_declared_bytes":part.get("size_bytes"),"saved_bytes":record["bytes"],"preservation":"Unmodified image bytes served by ChatGPT"})
    body="\n\n".join(body_parts)
    for a in attachments:
        body+="\n\n**Attachment:** "+a.get("name",a.get("id","File"))
        mounted=a.get("mounted_library_file_id","")
        if mounted.startswith("external-gdrive:file:"):
            body+=" — [Google Drive](https://drive.google.com/file/d/"+mounted.split(":")[-1]+"/view)"
    entries.append({"number":index,"id":m["id"],"role":m["author"]["role"],"channel":m.get("channel"),"timestamp":stamp(m.get("create_time")),"body":body,"source_text":text,"source_content":m["content"],"display_kind":"generated_image" if m.get("metadata",{}).get("image_gen_title") else "message"})
(out/f"{label}-conversation.json").write_text(json.dumps({"source":data["conversation_id"],"current_node":data["current_node"],"entries":entries},ensure_ascii=False,indent=2))
intro=f"# {label} — Conversation archive\n\nCaptured snapshot; exact capture time is in capture-audit.json. This readable edition follows the saved active conversation path. It includes every user message and every assistant text message addressed to the conversation, including progress text. Original formatting tokens are resolved using source citation metadata.\n\nThe accompanying original JSON preserves the entire returned message graph, including alternate branches, tool records, timestamps, metadata, and original text. The PDF is a readable view; the original JSON is the preservation master.\n\n"
md=intro+"\n\n".join(f'## {e["number"]:03d} · {e["role"].title()}'+(" · Progress" if e["channel"]=="commentary" else "")+f'\n\n{e["timestamp"]} · Message {e["id"]}\n\n{e["body"]}' for e in entries)
(out/f"{label}-conversation.md").write_text(md)
allmd=[f"# {label} — All original message records\n\nEvery source node is preserved in {label}-all-records.jsonl and {label}-original-source.json. This text companion serializes every content object without dropping types or fields.\n"]
for i,n in enumerate(nodes,1):
    m=n.get("message")
    if not m:continue
    allmd.append(f'## Record {i} · {m["author"]["role"]} · {m["id"]}\n\n'+json.dumps(m["content"],ensure_ascii=False,indent=2))
(out/f"{label}-all-content.md").write_text("\n\n".join(allmd))
assets=list({a["url"]:a for a in assets}.values())
(root/"assets-to-download.json").write_text(json.dumps(assets,indent=2))
(out/"artifacts"/"artifact-index.json").write_text(json.dumps({"written_artifacts":written,"embedded_widgets":widgets,"conversation_images":image_records,"referenced_images":assets,"native_document":None},ensure_ascii=False,indent=2))
audit={"captured_at":json.loads((root/"raw-status.json").read_text()).get("capture_completed_at"),"source_conversation_id":data["conversation_id"],"source_current_node":data["current_node"],"source_nodes":len(mp),"source_messages":sum(bool(n.get("message")) for n in nodes),"active_branch_nodes":len(branch),"active_branch_user_messages":sum(m["author"]["role"]=="user" for m in messages),"readable_messages":len(entries),"readable_source_characters":sum(len(e["source_text"]) for e in entries),"raw_source_sha256":hashlib.sha256((root/"raw-source.json").read_bytes()).hexdigest(),"raw_source_bytes":(root/"raw-source.json").stat().st_size,"written_artifact_versions":len(written),"first_message":entries[0]["source_text"],"last_message_id":entries[-1]["id"],"raw_source_tab_id":json.loads((root/"raw-status.json").read_text()).get("source_tab_id")}
(out/"capture-audit.json").write_text(json.dumps(audit,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in audit.items() if k!="first_message"},ensure_ascii=False,indent=2));print("Referenced images",len(assets))
