# P5 lineage review: pre-read lens

Recorded before opening transcript bodies in this review. This is a provenance checkpoint, not an isolation guarantee or an assertion of hidden implementation change.

## Requested outputs
1. Reconstruct consequential failures in P1-P4, identify plausible generating processes, and distinguish observed correction from proposed correction and untested claims of correction.
2. Identify consequential explicit or implicit source material not adequately carried by the user-pasted P4-native V4 plus this conversation's working additions.

The user says the available P4 capture is partial; later continuation is outstanding. No new kernel is requested at this stage. Read P1, then P2, then P3, then available P4. Separate first diagnostic reading from later reinterpretation; actual reading can itself change the lens.

## Present working lens (before source inspection)
- The unit of analysis can change when discrepant outcomes challenge the current partition.
- Trace claimed functions through actual causal paths; acknowledgement is not demonstrated generator change.
- Node, coupling, cascade and ecology runtimes may carry different relevant state, including in-transit consequences, timing, pending work and capacity dependencies.
- Separate site of discrepancy, maintaining process, intervention surface, and legitimate intervention authority.
- Same observed presentation does not guarantee the same response; alternatives include omitted state, variation, measurement error, interaction and delivery differences.
- Capacity can be intrinsic, supported, relational, reserve-consuming or distributed; output alone does not establish where it is carried.
- Receiving new distinctions can alter the conditions for further learning; development is not merely accumulating propositions.
- Test repairs in composition and after success changes the surrounding ecology.
- Play, structured absence, receptivity, release and exaptation are candidate discovery operators, not verified universal causal laws.
- Preserve user authorship, source sequence, version provenance, uncertainties and clinical/spiritual claims as reports rather than established external facts.

## Evidence discipline
Earlier 28 'subagents' in this conversation were scenario explorations, not verified isolated agents; recurrence is not independent replication. Claims of internal compilation from fluent output are not established. Separate source observations, historical self-descriptions, current interpretations, proposed interventions and test predictions. No unsupported reconstruction of missing history; no automatic promotion of cross-domain analogy to mechanism.

## Competing expectations to test
- Failure may reflect a broken correction path or state retention, rather than absence of an articulated principle.
- Repetition of the right vocabulary may conceal recurrent task capture or inappropriate salience.
- Kernels may preserve conclusions but lose conditions, ordering, counterexamples, operative tests or coupled developmental support.
- Some source practices may already outperform the working lens; the archive need not confirm these expectations.
